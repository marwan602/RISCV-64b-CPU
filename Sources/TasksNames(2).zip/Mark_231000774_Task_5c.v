`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/29/2025 04:28:35 AM
// Design Name: 
// Module Name: RISKV_CPU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps

module RISKV_CPU(
    input clk,
    input rst
);

    // Program Counter Signals
    wire [63:0] PC_In;
    wire [63:0] PC_Out;
    wire [63:0] PC_Plus_4;
    wire [63:0] PC_Branch;
    wire [63:0] Next_PC_Mux_Out;

    // Instruction Memory Signals
    wire [31:0] Instruction;

    // Control Unit Signals
    wire Branch;
    wire MemRead;
    wire MemToReg;
    wire MemWrite;
    wire ALUSrc;
    wire RegWrite;
    wire [3:0] AluCtrl;

    // Register File Signals
    wire [63:0] ReadData1;
    wire [63:0] ReadData2;
    wire [63:0] WriteBack_Data;

    // Immediate Generator Signals
    wire [63:0] Imm_Out;

    // ALU Signals
    wire [63:0] ALU_Src_B;
    wire [63:0] ALU_Result;
    wire Zero;

    // Data Memory Signals
    wire [63:0] Mem_ReadData;

    assign PC_Plus_4 = PC_Out + 64'd4;
    assign PC_Branch = PC_Out + (Imm_Out); 
    assign Next_PC_Mux_Out = (Branch & Zero) ? PC_Branch : PC_Plus_4;
    assign ALU_Src_B = (ALUSrc) ? Imm_Out : ReadData2;

    assign WriteBack_Data = (MemToReg) ? Mem_ReadData : ALU_Result;

    ProgramCounter PC_Mod (
        .clk(clk),
        .reset(rst),
        .PC_In(Next_PC_Mux_Out),
        .PC_Out(PC_Out)
    );

    InstructionMemory Instr_Mem (
        .addr(PC_Out),
        .instr(Instruction)
    );

    C_Unit Control_Unit (
        .instruction(Instruction),
        .branch(Branch),
        .MemRead(MemRead),
        .MemToReg(MemToReg),
        .MemWrite(MemWrite),
        .AluSrc(ALUSrc),
        .RegWrite(RegWrite),
        .AluCtrl(AluCtrl)
    );

    RegisterFile Reg_File (
        .clk(clk),
        .RegWrite(RegWrite),
        .ReadRegister1(Instruction[19:15]), // rs1
        .ReadRegister2(Instruction[24:20]), // rs2
        .WriteRegister(Instruction[11:7]),  // rd
        .WriteData(WriteBack_Data),
        .ReadData1(ReadData1),
        .ReadData2(ReadData2)
    );

    ImmGen Imm_Generator (
        .Instruction(Instruction),
        .Immediate(Imm_Out)
    );

    ALU ALU_Mod (
        .A(ReadData1),
        .B(ALU_Src_B),
        .ALUCtrl(AluCtrl),
        .ALUResult(ALU_Result),
        .Zero(Zero)
    );

    DataMemory Data_Mem (
        .clk(clk),
        .MemRead(MemRead),
        .MemWrite(MemWrite),
        .Address(ALU_Result),
        .WriteData(ReadData2),
        .ReadData(Mem_ReadData)
    );

endmodule
