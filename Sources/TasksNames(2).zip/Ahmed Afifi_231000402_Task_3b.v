`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: Nile University
// Engineer: Ahmed Afifi
// 
// Create Date: 12/26/2025 09:55:16 PM
// Design Name: My robust, most exciting, immediate generator
// Module Name: ImmGen
// Project Name: RISC-V Single Cycle Processor by RISK-V
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ImmGen(
    input [31:0] Instruction,
    output reg [63:0] Immediate
    );
    
    wire [6:0] opcode = Instruction[6:0];
    
    always @(*) begin
        case (opcode)
            7'b0010011, 7'b0000011: begin // R-Type
                Immediate = {{52{Instruction[31]}}, Instruction[31:20]};
            end
            
            7'b0100011: begin // S-Type
                Immediate = {{52{Instruction[31]}}, Instruction[31:25], Instruction[11:7]};
            end
            
            7'b1100011: begin // B-Type
                Immediate = {{52{Instruction[31]}}, Instruction[7], Instruction[30:25], Instruction[11:8], 1'b0};
            end
        endcase
    end
endmodule
