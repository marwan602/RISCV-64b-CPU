`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: Nile University
// Engineer: Mark
// 
// Create Date: 12/29/2025 03:28:41 AM
// Design Name: 
// Module Name: DataMemory
// Project Name: RISC-V Single Cycle Processor by RISK-V
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module DataMemory(
    input clk,
    input MemRead,
    input MemWrite,
    input [63:0] Address,
    input [63:0] WriteData,
    output reg [63:0] ReadData
    );

    reg [63:0] mem_array [0:63];
    
    always @(*) begin
        if (MemRead) begin
            ReadData = mem_array[Address[8:3]];
        end
        else begin
            ReadData = 64'd0;
        end
    end

    always @(posedge clk) begin
        if (MemWrite) begin
            mem_array[Address[8:3]] <= WriteData;
        end
    end

endmodule
