`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/29/2025 04:23:04 AM
// Design Name: 
// Module Name: ProgramCounter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////
// Student Name: Steven Wilson
// Student ID: 231001331
// Module Name: ProgramCounter
// Description: 64-bit Program Counter (PC) register for RISC-V Processor.
//              It updates on the positive edge of the clock.
//              If reset is high, PC resets to 0.
//////////////////////////////////////////////////////////////////////////////////

module ProgramCounter(
    // Clock signal
    input clk,
    // Synchronous reset
    input reset,
    // Next PC address (comes from MUX)
    input [63:0] PC_In,
    // Current PC address (goes to Instruction Memory)
    output reg [63:0] PC_Out
    );

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            // Reset PC to 0
            PC_Out <= 64'b0;
        end else begin
            // Update PC to the next address
            PC_Out <= PC_In;
        end
    end

endmodule
