`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: Nile University
// Engineer: Ahmed Afifi 
// 
// Create Date: 12/26/2025 09:55:16 PM
// Design Name: My robust, most exciting, register file
// Module Name: RegisterFile
// Project Name: RISC-V Single Cycle Processor by RISK-V
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module RegisterFile(
    input clk,
    input RegWrite,
    input [4:0] ReadRegister1,
    input [4:0] ReadRegister2,
    input [4:0] WriteRegister,
    input [63:0] WriteData,
    output [63:0] ReadData1,
    output [63:0] ReadData2
    );
    
    reg [63:0] registers[31:0];
    
    initial begin
        registers[0] = 64'b0;
    end
    
    assign ReadData1 = (ReadRegister1 == 0) ? 64'b0 : registers[ReadRegister1];
    assign ReadData2 = (ReadRegister2 == 0) ? 64'b0 : registers[ReadRegister2];
    
    always @(posedge clk) begin
        if (RegWrite && WriteRegister != 0) begin
            registers[WriteRegister] <= WriteData;
        end 
    end
endmodule
