`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/29/2025 04:20:53 AM
// Design Name: 
// Module Name: InstructionMemory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module InstructionMemory(
    input  wire [63:0] addr,     // Byte address from PC
    output reg  [31:0] instr
);

  reg [31:0] mem [0:63];       // 64 x 32-bit instructions

    initial begin
        $readmemh("C:/Users/Ahmed/University/CSCI311/RISK-V Processor/RISK-V Processor.srcs/sources_1/new/instructions.mem", mem);
    end

    always @(*) begin
   // Divides our pc by 4 to return exact index of the current instruction
   // Word-aligned indexing
        instr = mem[addr >> 2];  
    end

endmodule
