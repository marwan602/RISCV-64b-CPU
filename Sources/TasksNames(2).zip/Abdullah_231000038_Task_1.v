`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/29/2025 04:26:05 AM
// Design Name: 
// Module Name: ALU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

// 64-bit ALU
// 0000 AND
// 0001 OR
// 0010 ADD
// 0110 SUB
// 1100 XOR
// 1000 SLL
// 1001 SRL
// 1010 SRA

module ALU(
    input  wire [63:0] A,
    input  wire [63:0] B,
    input  wire [3:0]  ALUCtrl,
    output reg  [63:0] ALUResult,
    output wire        Zero
);
  
  wire [5:0] shiftamount = B[5:0];

    always @(*) begin
        case (ALUCtrl)
            4'b0000: ALUResult = A & B;                  // AND
            4'b0001: ALUResult = A | B;                  // OR
            4'b0010: ALUResult = A + B;                  // ADD
            4'b0110: ALUResult = A - B;                  // SUB
            4'b1100: ALUResult = A ^ B;                  // XOR
            4'b1000: ALUResult = A << shiftamount;             // SLL
            4'b1001: ALUResult = A >> shiftamount;             // SRL
            4'b1010: ALUResult = $signed(A) >>> shiftamount;     // SRA we dont need this, but our control unit already has it, so why not
            default: ALUResult = 64'b0;                  // safe default
        endcase
    end

    assign Zero = (ALUResult == 64'b0);

endmodule
