`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/29/2025 04:10:23 AM
// Design Name: 
// Module Name: C_Unit
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// Code your design here
module C_Unit(
  input wire [31:0] instruction,
  output reg branch,
  output reg MemRead,
  output reg MemToReg,
  output reg MemWrite,
  output reg AluSrc,
  output reg RegWrite,

  output reg [3:0] AluCtrl
);
  wire [6:0] opcode = instruction[6:0];
  wire [2:0] funct3 = instruction[14:12];
  wire funct7 = instruction[30];
  always @(*) begin
  case (opcode)
    7'b0110011: begin // R-type instruction
      branch = 0;
      MemRead = 0;
      MemToReg = 0;
      MemWrite = 0;
      AluSrc = 0;
      RegWrite = 1;
      case(funct3)
        3'b111: AluCtrl = 4'b0000; //AND alu code
        3'b000: AluCtrl = (funct7)? 4'b0110 : 4'b0010; //Sub or Add
        3'b110: AluCtrl = 4'b0001; //OR
        3'b100: AluCtrl = 4'b1100; //XOR
        3'b001: AluCtrl = 4'b1000; //Shift Left
        3'b101: AluCtrl = (funct7)?  4'b1010 : 4'b1001; //Shift right arithmetic and logical
        default: AluCtrl = 4'b0000;
      endcase
    end
    7'b0010011: begin //I-type instruction
      branch = 0;
      MemRead = 0;
      MemToReg = 0;
      MemWrite = 0;
      AluSrc = 1;
      RegWrite = 1;
      case(funct3)
        3'b111: AluCtrl = 4'b0000; //andi alu code
        3'b000: AluCtrl = 4'b0010;  //addi (sub is just negative add)
        3'b110: AluCtrl = 4'b0001; //ori
        3'b100: AluCtrl = 4'b1100; //xori
        3'b001: AluCtrl = 4'b1000; //slli
        3'b101: AluCtrl = (funct7)? 4'b1010 : 4'b1001; //srai and srli
        default: AluCtrl = 4'b0000;
      endcase
    end
    7'b0000011: begin //Load instruction   
      branch = 0;
      MemRead = 1;
      MemToReg = 1;
      MemWrite = 0;
      AluSrc = 1;
      RegWrite = 1;
      AluCtrl = 4'b0010; //load always adds address
    end
    7'b0100011: begin //store instruction
      branch = 0;
      MemRead = 0;
      MemToReg = 0; //don't care, but we'll set it to 0
      MemWrite = 1;
      AluSrc = 1;
      RegWrite = 0;
      AluCtrl = 4'b0010; //same as load
    end
    7'b1100011: begin //branch instruction
      branch = 1;
      MemRead = 0;
      MemToReg = 0; //don't care, but we'll set it to 0
      MemWrite = 0;
      AluSrc = 0;
      RegWrite = 0;
      AluCtrl = 4'b0110; //subtract to compare
    end
      default: begin
      branch = 0;
      MemRead = 0;
      MemToReg = 0;
      MemWrite = 0;
      AluSrc = 0;
      RegWrite = 0;
      AluCtrl = 4'b0000;
    end
  endcase
  end
endmodule
