`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: Nile University
// Engineer: Ahmed Afifi
// 
// Create Date: 12/28/2025 11:19:14 PM
// Design Name: Just to prove that I'am always correct
// Module Name: ImmGen_tb
// Project Name: RISC-V Single Cycle Processor by RISK-V 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ImmGen_tb;
    reg clk;
    reg [31:0] Instruction;
    wire [63:0] Immediate;
    
    ImmGen UnbeatableGenerator
    (
        .Instruction(Instruction),
        .Immediate(Immediate)
    );
    
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end
    
    initial begin
        Instruction = 0;
        
        Instruction = 32'b00000011001000010000000010010011; // addi x1, x2, 50
        #10;
        if (Immediate === 50) $display("PASSED: addi immediate extracted successfully!!!!");
        else $display("FAILED: I am very sad about it (addi).");
        
        Instruction = 32'b00000000100000001011000100000011; // ld x2, 8(x1)
        #10;
        if (Immediate === 8) $display("PASSED: ld immediate extracted successfully!!!!");
        else $display("FAILED: I am very sad about it (ld).");
        
        Instruction = 32'b00000000000100100011100000100011; // sd x1, 16(x4)
        #10;
        if (Immediate === 16) $display("PASSED: sd immediate extracted successfully!!!!");
        else $display("FAILED: I am very sad about it (sd).");
        
        Instruction = 32'b00011110001000001000101001100011; // beq x1, x2, 500
        #10;
        if (Immediate === 500) $display("PASSED: beq immediate extracted successfully!!!!");
        else $display("FAILED: I am very sad about it (beq).");
    end
endmodule
