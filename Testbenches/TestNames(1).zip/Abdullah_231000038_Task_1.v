`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/29/2025 04:26:52 AM
// Design Name: 
// Module Name: ALU_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps

module testing_ALU;

    reg  [63:0] A, B;
    reg  [3:0]  ALUCtrl;
    wire [63:0] ALUResult;
    wire        Zero;

    // Instantiate the ALU
    ALU uut (
        .A(A),
        .B(B),
        .ALUCtrl(ALUCtrl),
        .ALUResult(ALUResult),
        .Zero(Zero)
    );

    initial begin
        $display("=== ALU Testbench Start ===");

        // ADD
        A = 64'd10; 
        B = 64'd7;  
        ALUCtrl = 4'b0010; #10;
        $display("ADD: A=%0d B=%0d Result=%0d Zero=%b", A, B, ALUResult, Zero);

        // SUB -> Zero should be 1
        A = 64'd9; 
        B = 64'd9;  
        ALUCtrl = 4'b0110; #10;
        $display("SUB: A=%0d B=%0d Result=%0d Zero=%b", A, B, ALUResult, Zero);

        // AND
        A = 64'hF0F0;
        B = 64'h0FF0;
        ALUCtrl = 4'b0000; #10;
        $display("AND: A=%h B=%h Result=%h Zero=%b", A, B, ALUResult, Zero);

        // OR
        A = 64'hF0F0;
        B = 64'h0FF0;
        ALUCtrl = 4'b0001; #10;
        $display(" OR: A=%h B=%h Result=%h Zero=%b", A, B, ALUResult, Zero);

        // XOR
        A = 64'hAAAA;
        B = 64'h0F0F;
        ALUCtrl = 4'b1100; #10;
        $display("XOR: A=%h B=%h Result=%h Zero=%b", A, B, ALUResult, Zero);

        // SLL
        // shift left by B[5:0] = 4
        A = 64'h1;
        B = 64'd4;
        ALUCtrl = 4'b1000; #10;
        $display("SLL: A=%h shift=%0d Result=%h Zero=%b", A, B[5:0], ALUResult, Zero);

        // SRL
        // shift right by B[5:0] = 7
        A = 64'h80; 
        B = 64'd7; 
        ALUCtrl = 4'b1001; #10;
        $display("SRL: A=%h shift=%0d Result=%h Zero=%b", A, B[5:0], ALUResult, Zero);

        $display("=== ALU Testbench End ===");
        $stop;
    end

endmodule
