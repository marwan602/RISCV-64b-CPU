`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/29/2025 04:24:14 AM
// Design Name: 
// Module Name: ProgramCounter_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module tb_ProgramCounter;

    reg clk, reset;
    reg Branch, Zero;
    reg [63:0] Imm;

    wire [63:0] PC_Out, PC_In, PC_Plus4, PC_Branch;
    wire PCSrc;

    ProgramCounter uut (
        .clk(clk), 
        .reset(reset), 
        .PC_In(PC_In), 
        .PC_Out(PC_Out)
    );

    assign PC_Plus4  = PC_Out + 64'd4;
    assign PC_Branch = PC_Out + Imm;
    assign PCSrc     = Branch & Zero;
    assign PC_In     = PCSrc ? PC_Branch : PC_Plus4;

    always #5 clk = ~clk;   // 10ns clock period

    initial begin
        clk = 0;
        reset = 1;
        Branch = 0;
        Zero = 0;
        Imm = 0;

        $monitor("Time=%0t | PC_Out=%0d | Branch=%b Zero=%b | Imm=%0d | PCSrc=%b | Next_PC=%0d",
                 $time, PC_Out, Branch, Zero, Imm, PCSrc, PC_In);

        #10 reset = 0;

        #10;   // PC = 4
        #10;   // PC = 8

        Imm = 64'd20;
        Branch = 1;
        Zero = 0;
        #10;   // PC = 12

        Zero = 1;
        #10;   // PC = 32

        Branch = 0;
        Zero = 0;
        #10;   // PC = 36

        $stop;
    end

endmodule