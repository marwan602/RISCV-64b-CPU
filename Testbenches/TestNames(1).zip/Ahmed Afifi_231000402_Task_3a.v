`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: Nile University
// Engineer: Ahmed Afifi
// 
// Create Date: 12/28/2025 11:14:28 PM
// Design Name: Just to prove that I'am always correct
// Module Name: RegisterFile_tb
// Project Name: RISC-V Single Cycle Processor by RISK-V
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module RegisterFile_tb;
    reg clk;
    reg RegWrite;
    reg [4:0] ReadReg1, ReadReg2, WriteReg;
    reg [63:0] WriteData;
    wire [63:0] ReadData1, ReadData2;
    
    RegisterFile RegFile
    (
        .clk(clk),
        .RegWrite(RegWrite),
        .ReadRegister1(ReadReg1),
        .ReadRegister2(ReadReg2),
        .WriteRegister(WriteReg),
        .WriteData(WriteData),
        .ReadData1(ReadData1),
        .ReadData2(ReadData2)
    );
    
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end
    
    initial begin
        RegWrite = 0;
        WriteReg = 0;
        WriteData = 0;
        ReadReg1 = 0;
        ReadReg2 = 0;
        
        $display("**** Starting Register File Test ****");
        
        // Write to X1
        #10 WriteReg = 5'd1; 
        WriteData = 64'hFFFF;
        RegWrite = 1;
        #10 RegWrite = 0;
        
        // Read from X1 in the middle of the cycle
        #3 ReadReg1 = 5'd1;
        #1
        if (ReadData1 === 64'hFFFF) $display("PASSED: Wrote to X1 and retrieved its data correctly");
        else $display("FAILED: Read Data = %h", ReadData1);
        
        // Testing hardwired X0
        #10 WriteReg = 5'd0;
        WriteData = 64'hFFFF;
        RegWrite = 1;
        #10 RegWrite = 0;
        
        #5 ReadReg2 = 5'd0;
        #1
        if (ReadData1 === 0) $display("PASSED: X0 actually wired to zero!!!!");
        else $display("FAILED: X0 was overwritten :(");
    end
endmodule
