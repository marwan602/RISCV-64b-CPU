`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/29/2025 04:14:19 AM
// Design Name: 
// Module Name: C_Unit_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module C_Unit_tb;

  // Inputs
  reg [31:0] instruction;

  // Outputs
  wire branch;
  wire MemRead;
  wire MemToReg;
  wire MemWrite;
  wire AluSrc;
  wire RegWrite;
  wire [3:0] AluCtrl;

  // Instantiate the Control Unit
  C_Unit uut (
    .instruction(instruction),
    .branch(branch),
    .MemRead(MemRead),
    .MemToReg(MemToReg),
    .MemWrite(MemWrite),
    .AluSrc(AluSrc),
    .RegWrite(RegWrite),
    .AluCtrl(AluCtrl)
  );

  initial begin
    // Initialize
    instruction = 32'b0;

    // ---- R-type ----
    instruction = 32'b0000000_00001_00010_000_00011_0110011; #10; // ADD
    $display("ADD  -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    instruction = 32'b0100000_00001_00010_000_00011_0110011; #10; // SUB
    $display("SUB  -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    instruction = 32'b0000000_00001_00010_111_00011_0110011; #10; // AND
    $display("AND  -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    instruction = 32'b0000000_00001_00010_110_00011_0110011; #10; // OR
    $display("OR   -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    instruction = 32'b0000000_00001_00010_100_00011_0110011; #10; // XOR
    $display("XOR  -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    instruction = 32'b0000000_00001_00010_001_00011_0110011; #10; // SLL
    $display("SLL  -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    instruction = 32'b0000000_00001_00010_101_00011_0110011; #10; // SRL
    $display("SRL  -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    instruction = 32'b0100000_00001_00010_101_00011_0110011; #10; // SRA
    $display("SRA  -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    // ---- I-type ----
    instruction = 32'b000000000001_00010_000_00011_0010011; #10; // ADDI
    $display("ADDI -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    instruction = 32'b000000000001_00010_111_00011_0010011; #10; // ANDI
    $display("ANDI -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    instruction = 32'b000000000001_00010_110_00011_0010011; #10; // ORI
    $display("ORI  -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    instruction = 32'b000000000001_00010_100_00011_0010011; #10; // XORI
    $display("XORI -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    instruction = 32'b000000000001_00010_001_00011_0010011; #10; // SLLI
    $display("SLLI -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    instruction = 32'b000000000001_00010_101_00011_0010011; #10; // SRLI
    $display("SRLI -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    instruction = 32'b010000000001_00010_101_00011_0010011; #10; // SRAI
    $display("SRAI -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    // ---- Load ----
    instruction = 32'b000000000100_00010_011_00011_0000011; #10; // LD
    $display("LD   -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    // ---- Store ----
    instruction = 32'b000000000010_00010_010_00011_0100011; #10; // SD
    $display("SD   -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    // ---- Branch ----
    instruction = 32'b000000000001_00010_000_00011_1100011; #10; // BEQ
    $display("BEQ  -> Branch=%b MemRead=%b MemToReg=%b MemWrite=%b ALUSrc=%b RegWrite=%b ALUCtrl=%b",
             branch, MemRead, MemToReg, MemWrite, AluSrc, RegWrite, AluCtrl);

    $display("All tests completed.");
  end

endmodule

