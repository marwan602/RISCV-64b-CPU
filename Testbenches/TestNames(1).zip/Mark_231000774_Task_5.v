`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/29/2025 05:21:51 AM
// Design Name: 
// Module Name: RISKV_CPU_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module tb_RISKV_CPU;

    // 1. Inputs to the CPU
    reg clk;
    reg rst;

    // 2. Instantiate the Unit Under Test (UUT)
    RISKV_CPU uut (
        .clk(clk),
        .rst(rst)
    );

    // 3. Clock Generation (100 MHz)
    // Period = 10ns (5ns high, 5ns low)
    initial begin
        clk = 0;
        forever #5 clk = ~clk; 
    end

    // 4. Test Sequence
    initial begin
        // A. Initialize Inputs
        rst = 1; // Start in Reset to clear PC and Registers

        // B. Hold Reset for a few cycles
        #20;
        
        // C. Release Reset (Start Execution)
        rst = 0;
        $display("--- Reset Released. CPU Started ---");

        // D. Let the simulation run for enough time to execute your program
        // 500ns = 50 clock cycles (enough for a small program)
        #500;
        
        // E. Stop simulation
        $display("--- Simulation Finished ---");
        $stop;
    end
    
    // 5. Optional: Console Monitor (Spying on Internal Signals)
    // Since your CPU has no outputs, we can "peek" inside using dot notation
    // to verify the PC is moving without opening the waveform every time.
    initial begin
        $monitor("Time=%0t | PC=%h | Instr=%h", 
                 $time, uut.PC_Out, uut.Instruction);
    end

endmodule
